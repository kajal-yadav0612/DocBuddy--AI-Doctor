import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import './App.css';
import chatbotIcon from './assets/chatbot.png';

function App() {
  const [question, setQuestion] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [isChatting, setIsChatting] = useState(false);
  const chatWindowRef = useRef(null);
  const pageRef = useRef(null);

  // Function to get current time
  const getCurrentTime = () => {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  async function generateAnswer() {
    if (!question.trim()) return;

    const userMessage = { sender: 'You', text: question, time: getCurrentTime() };
    setChatHistory((prevHistory) => [...prevHistory, userMessage]);
    setQuestion('');
    setIsChatting(true);

    try {
      const response = await axios({
        url: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyC8mn1Yy4SZ4V52MuK9u_4VFP4YV9TKEtI',
        method: 'post',
        data: {
          contents: [{ parts: [{ text: userMessage.text }] }],
        },
      });

      let botResponse = response.data.candidates[0].content.parts[0].text;
      const wordLimit = 210;
      const words = botResponse.split(' ');
      if (words.length > wordLimit) {
        botResponse = words.slice(0, wordLimit).join(' ') + '...';
      }

      const botMessage = { sender: 'AI Doctor', text: botResponse, time: getCurrentTime() };
      setChatHistory((prevHistory) => [...prevHistory, botMessage]);
      setIsChatting(false);
    } catch (error) {
      setChatHistory((prevHistory) => [
        ...prevHistory,
        { sender: 'AI Doctor', text: 'Error fetching response', time: getCurrentTime() },
      ]);
      console.error(error);
      setIsChatting(false);
    }
  }

  useEffect(() => {
    if (chatWindowRef.current) {
      chatWindowRef.current.scrollTo({ top: chatWindowRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [chatHistory]);

  // Auto page scrolling effect
  useEffect(() => {
    let direction = 1; // 1 for down, -1 for up
    const scrollSpeed = 1; // Adjust speed of scrolling

    const scrollPage = () => {
      if (pageRef.current) {
        pageRef.current.scrollBy({ top: scrollSpeed * direction, behavior: 'smooth' });

        if (window.scrollY + window.innerHeight >= document.body.scrollHeight) {
          direction = -1; // Reverse direction when reaching bottom
        } else if (window.scrollY <= 0) {
          direction = 1; // Reverse direction when reaching top
        }
      }
    };

    const interval = setInterval(scrollPage, 50); // Adjust interval for smoothness

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="page-container" ref={pageRef}>
      <div className="app-container">
        {/* Chatbot Icon & Logo - Fixed at the Top */}
        <div className="chatbot-icon-wrapper">
          <img src={chatbotIcon} alt="Chatbot" className="chatbot-icon" />
          <span className="ai-doctor-logo">AI Doctor</span>
        </div>

        {/* Chat Container */}
        <div className="chat-container">
          <div className="chat-window" ref={chatWindowRef}>
            {chatHistory.map((msg, index) => (
              <div key={index} className={msg.sender === 'You' ? 'user-box' : 'bot-box'}>
                <strong>{msg.sender}:</strong> {msg.text}
                <div className="timestamp">{msg.time}</div>
              </div>
            ))}
          </div>

          {/* Chat Input */}
          <textarea
            className="chat-input"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask me anything..."
          ></textarea>

          <button className="chat-button" onClick={generateAnswer} disabled={isChatting}>
            {isChatting ? 'Thinking...' : 'Ask Me...'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
